LUCREY — AVATARES CHIBI (REFERÊNCIA ENVIADA)
20 avatares individuais em PNG, cada um com 48x48 pixels.
Spritesheet: 240x192 px, organizada em 5 colunas e 4 linhas.
Para AnimatedSprite2D/Sprite2D com spritesheet: Hframes=5, Vframes=4.
Fundos em azul-marinho com elementos gráficos do mercado financeiro.
